#ifndef SECURE_PACMTE_H
#define SECURE_PACMTE_H

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/auxv.h>
#include <sys/prctl.h>


#define PAC_MODIFIER 0x1234000000000000
#define HWCAP2_MTE              (1 << 18)
#define PROT_MTE                 0x20
#define PAGE_SIZE 4096

#define PR_SET_TAGGED_ADDR_CTRL 55
#define PR_GET_TAGGED_ADDR_CTRL 56
#define PR_TAGGED_ADDR_ENABLE   (1UL << 0)
#define PR_MTE_TCF_SHIFT        1
#define PR_MTE_TCF_NONE         (0UL << PR_MTE_TCF_SHIFT)
#define PR_MTE_TCF_SYNC         (1UL << PR_MTE_TCF_SHIFT)
#define PR_MTE_TCF_ASYNC        (2UL << PR_MTE_TCF_SHIFT)
#define PR_MTE_TCF_MASK         (3UL << PR_MTE_TCF_SHIFT)
#define PR_MTE_TAG_SHIFT        3
#define PR_MTE_TAG_MASK         (0xffffUL << PR_MTE_TAG_SHIFT)





#define insert_random_tag(ptr) ({                 \
		    uint64_t __val;                               \
		        asm("irg %0, %1" : "=r" (__val) : "r" (ptr)); \
			    __val;                                        \
			    })

#define set_tag(tagged_addr) do {                                 \
	    asm volatile("stg %0, [%0]" : : "r" (tagged_addr) : "memory");\
} while (0)

static inline void init_mte_if_needed() {
	    static int initialized = 0;
	        if (initialized) return;

	 unsigned long hwcap2 = getauxval(AT_HWCAP2);
	       if (!(hwcap2 & HWCAP2_MTE)) {
	        fprintf(stderr, "[PACMTE] MTE not supported\n");
					        exit(EXIT_FAILURE);
						    }

		  if (prctl(PR_SET_TAGGED_ADDR_CTRL,
	  PR_TAGGED_ADDR_ENABLE | PR_MTE_TCF_SYNC | (0xfffeUL << PR_MTE_TAG_SHIFT),							                0, 0, 0)) {
		            perror("[PACMTE] prctl() failed");
			            exit(EXIT_FAILURE);
						        }

			        initialized = 1;
}

#define MTE_STRIP_TAG(ptr) ((void *)((uint64_t)(ptr) & 0x00FFFFFFFFFFFFFF))


static inline uint64_t sign_pointer(uint64_t ptr, uint64_t modifier) {
	    uint64_t signed_ptr;
	        asm volatile("pacib %0, %1"
	                : "=r"(signed_ptr)
	                  : "r"(modifier), "0"(ptr)
								                   : "memory");
		    return signed_ptr;
}

static inline uint64_t authenticate_pointer(uint64_t signed_ptr, uint64_t modifier) {
	    uint64_t auth_ptr;
	        asm volatile("autib %0, %1"
		              : "=r"(auth_ptr)
	                 : "r"(modifier), "0"(signed_ptr)							                   : "memory");
		    return auth_ptr;
}

static inline uint64_t pacmte_alloc(size_t size) {
	    init_mte_if_needed();
	   
	        void *raw = malloc(size);
		    if (!raw) return 0;

	       void *tagged = (void *)insert_random_tag(raw);
		    set_tag(tagged);
	/*	 printf("\ntagged pointer: 0x%016llx\n", tagged); */
	        uint64_t pointer= sign_pointer((uint64_t)tagged, PAC_MODIFIER);
	
		 return pointer;
}

static inline void final_free(void *ptr) {
	  
         uint64_t pac;
	
          pac=authenticate_pointer(ptr,PAC_MODIFIER);
         
	  free(MTE_STRIP_TAG(pac));
	
}

#endif 

