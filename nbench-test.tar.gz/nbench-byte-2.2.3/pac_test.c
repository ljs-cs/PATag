nclude "pac_test.h"


void* pac_malloc(size_t size) {
	            void* ptr = malloc(size);
		                    if (!ptr) return NULL;
				                    printf("generated org pointer is: %p\n", ptr);
						                        return (void*)sign_pointer((uint64_t)ptr, PAC_MODIFIER);
}

void pac_free(void* ptr) {
	            if (!ptr) return;
		             uint64_t authenticated_ptr = authenticate_pointer((uint64_t)ptr, PAC_MOO
					     DIFIER);
			               printf("authenticated pointer is: 0x%016lx\n", authenticated_ptr);
				                free((void*)authenticated_ptr);
}
