sprintf(buffer,"C compiler          : gcc version 9.4.0 (Ubuntu 9.4.0-1ubuntu1~18.04) \n");
output_string(buffer);
sprintf(buffer,"libc                : \n");
output_string(buffer);
