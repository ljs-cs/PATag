fndef PAC_TEST_H
#define PAC_TEST_H

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#define PAC_MODIFIER 0x12345678ABCDEF00


static inline uint64_t sign_pointer(uint64_t ptr, uint64_t modifier) {
	            uint64_t signed_ptr;
		                    asm volatile(
						                                          "pacib %0, %1"
											                                  : "=r"(signed_ptr)
															                                          : "r"(modifier), "0"(ptr)
																				                                          : "memory");
				                        return signed_ptr;
}


static inline uint64_t authenticate_pointer(uint64_t signed_ptr, uint64_t modifii
		er) {
	            uint64_t authenticated_ptr;
		                    asm volatile(
						                                    "autib %0, %1"
										                                   : "=r"(authenticated_ptr)
														                              : "r"(modifier), "0"(signed_ptr)
																	                                              : "memory");
				                        return authenticated_ptr;
}


void* pac_malloc(size_t size);
void pac_free(void* ptr);


#endif 
