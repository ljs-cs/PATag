#ifndef SECURE_CONFIG_H
#define SECURE_CONFIG_H

#ifdef USE_PAC
  #include "secure_pac.h"
  #define PAC_MODIFIER 0x1234000000000000UL
  #define secure_malloc(sz) pac_all(sz, PAC_MODIFIER)
  #define secure_free(ptr)  pac_de((ptr), PAC_MODIFIER)
  #define secure_auth(ptr)  ((void *)pac_au((ptr), PAC_MODIFIER))

#elif defined USE_PAC_SIMU
  #include "secure_pac.h"
  #define PAC_MODIFIER 0x1234000000000000UL
  #define secure_malloc(sz) sign_simu(sz, PAC_MODIFIER)
  #define secure_free(ptr)  free_simu((ptr), PAC_MODIFIER)
  #define secure_auth(ptr)  ((void *)au_simu((ptr), PAC_MODIFIER))


#elif defined USE_MTE
  #include "secure_mte.h"
  #define secure_malloc(sz) mte_alloc(sz)
  #define secure_free(p) mte_free(p)
  #define secure_auth(ptr) (ptr)

#elif defined USE_MTE_SIMU
  #include "secure_mte.h"
  #define secure_malloc(sz) mte_simu(sz)
  #define secure_free(p)  mte_free(p)
 #define secure_auth(ptr) (ptr)

#elif defined USE_PAC_MTE
  #include "secure_pac_mte.h"
  #define secure_malloc(sz) ((void *) secure_alloc(sz))
  #define secure_auth(ptr)  com_auth(ptr)
  #define secure_free(p)  final_free(p)

#elif defined USE_SIMU
  #include "secure_pac_mte.h"
  #define secure_malloc(sz) ((void *) alloc_simu(sz))
  #define secure_auth(ptr)  auth_simu(ptr)
  #define secure_free(p)  fe_simu(p)

#elif defined  USE_PACMTE

    #include "secure_pacmte.h"
    #define PAC_MODIFIER 0x1234000000000000UL
    #define secure_malloc(sz) pacmte_alloc(sz)
   #define secure_auth(ptr)  ((void *)authenticate_pointer((ptr), PAC_MODIFIER))
    #define secure_free(ptr) final_free(ptr)

#else
  #define secure_malloc(sz) malloc(sz)
  #define secure_auth(ptr)  (ptr)
  #define secure_free(p) free(p)
#endif



#endif

