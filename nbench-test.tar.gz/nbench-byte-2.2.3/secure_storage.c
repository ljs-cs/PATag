#include "secure_pac_mte.h"

ptr_mod_entry mod_table[MAX_PTRS];
int mod_table_idx = 0;
