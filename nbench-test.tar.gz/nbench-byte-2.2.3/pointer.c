#include <stdio.h>
int main(){
 printf("%d",(int)sizeof(long));
 return(0);
}

