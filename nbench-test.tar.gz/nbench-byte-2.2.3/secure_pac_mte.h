#ifndef SECURE_PAC_MTE_H
#define SECURE_PAC_MTE_H

#include "secure_pac.h"
#include "secure_mte.h"
#include <sys/prctl.h>
#include <sys/auxv.h>
#include <unistd.h>
#include <stdio.h>

#define HWCAP2_MTE              (1 << 18)
#define PR_SET_TAGGED_ADDR_CTRL 55
#define PR_TAGGED_ADDR_ENABLE   (1UL << 0)
#define PR_MTE_TCF_SYNC         (1UL << 1)
#define PR_MTE_TAG_SHIFT        3

#define MAX_PTRS 1024

typedef struct {
	                    void *ptr;
	                    uint64_t modifier;
} ptr_mod_entry;


extern ptr_mod_entry mod_table[MAX_PTRS];
extern int mod_table_idx;

static inline void init_mte_if_needed() {
	    static int initialized = 0;
	        if (initialized) return;
		    initialized = 1;

		   unsigned long hwcap2 = getauxval(AT_HWCAP2);
	   if (!(hwcap2 & HWCAP2_MTE)) {
		   fprintf(stderr, "MTE not supported\n");
			          exit(EXIT_FAILURE);
						        }

	  if (prctl(PR_SET_TAGGED_ADDR_CTRL,  PR_TAGGED_ADDR_ENABLE | PR_MTE_TCF_SYNC |								                    (0xfffe << PR_MTE_TAG_SHIFT), 0, 0, 0) != 0) {
			      perror("prctl failed to enable MTE");
				       exit(EXIT_FAILURE);
						    }
}
 
static inline void *secure_alloc(size_t size) {
	    void *raw = malloc(size);
	        if (!raw) return NULL;
		 init_mte_if_needed();  
		 void *tagged = MTE_INSERT_TAG(raw);
		  MTE_SET_TAG(tagged);
	 uint64_t mod = EXTRACT_MTE_TAG(tagged) << 56;
			    if (mod_table_idx < MAX_PTRS) {
	        mod_table[mod_table_idx].ptr = raw;
		        mod_table[mod_table_idx].modifier = mod;
			        mod_table_idx++;    }
	     else {
		  fprintf(stderr, "Modifier table full!\n");
			   exit(EXIT_FAILURE);       }
                 
                  return new_sign(tagged, mod);
}
static inline void *alloc_simu(size_t size) {
	      void *raw = malloc(size);
	      if (!raw) return NULL;
            asm volatile("nop");
	               asm volatile("nop");
			  asm volatile("nop");
             
             asm volatile("nop");
	     asm volatile("nop");
              asm volatile("nop");
	      asm volatile("nop");
	      asm volatile("nop");
	      asm volatile("nop");
	      asm volatile("nop");
	     asm volatile("nop");
	      asm volatile("nop");
	      asm volatile("nop");      
             return raw;
}

#define MTE_STRIP_TAG(ptr) ((void *)((uint64_t)(ptr) & 0x00FFFFFFFFFFFFFFUL))

#define STRIP_PAC(ptr) ((void *)((uint64_t)(ptr) & 0x0000FFFFFFFFFFFFUL))


static  void * com_auth(void * ptr) {
	   
       	void *access = STRIP_PAC(ptr);
         uint64_t mod = 0;
 for (int i = 0; i < mod_table_idx; i++) {
             if (mod_table[i].ptr == access) {
                  mod = mod_table[i].modifier; 
			break;	           } 
 }
           return  pac_au(ptr, mod);
		  
}

static void *auth_simu(void * ptr){

        void *access = STRIP_PAC(ptr);
	asm volatile("nop");
	asm volatile("nop");
	 asm volatile("nop");
	   asm volatile("nop");
	  asm volatile("nop");
	      asm volatile("nop");
		asm volatile("nop");
     return ptr;

}

 static  void final_free(void *ptr) {

               void *access = STRIP_PAC(ptr);

              uint64_t mod = 0;

           /*  printf("\nthe size of the modifier is : %d\n", mod_table_idx); */
	       for (int i = 0; i < mod_table_idx; i++) {
			    if (mod_table[i].ptr == access) {
				     mod = mod_table[i].modifier;		                                     break;
							                                                         }
					                        }
                      free(MTE_STRIP_TAG(pac_au(ptr, mod)));
	             for (int i = 0; i < mod_table_idx; i++) {
	      	  if (mod_table[i].ptr == access) {
                        mod_table[i] = mod_table[mod_table_idx - 1];
	      		      mod_table_idx--;
	      			            break;
	      					  }	  }
              
	
 }
static void fe_simu(void * ptr){

	        void *access = STRIP_PAC(ptr);
		    asm volatile("nop");
	            asm volatile("nop");
	             asm volatile("nop");
		    asm volatile("nop");
                    asm volatile("nop");
                  asm volatile("nop");					                    asm volatile("nop");
	    	  free(ptr);
}


#endif

