#ifndef SECURE_MTE_H
#define SECURE_MTE_H

#include <stdint.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <sys/auxv.h>
#include <sys/mman.h>
#include <unistd.h>


#define HWCAP2_MTE              (1 << 18)
#define PROT_MTE                0x20
#define PR_SET_TAGGED_ADDR_CTRL 55
#define PR_TAGGED_ADDR_ENABLE   (1UL << 0)
#define PR_MTE_TCF_SYNC         (1UL << 1)
#define PR_MTE_TAG_SHIFT        3



#define EXTRACT_MTE_TAG(ptr)  (((uint64_t)(ptr) >> 56) & 0xF)

#define MTE_INSERT_TAG(ptr) ({ \
		    uint64_t __val; \
		        asm("irg %0, %1" : "=r" (__val) : "r" (ptr)); \
			    (void *)__val; \
			    })

#define MTE_SET_TAG(ptr) do { \
	    asm volatile("stg %0, [%0]" : : "r" (ptr) : "memory"); \
} while (0)


#define MTE_GET_TAG(ptr) ({                                      \
  uint64_t _tmp = ((uint64_t)(ptr)) & 0x00FFFFFFFFFFFFFF;    \
	 _tmp |= (0x5UL << 56);                                       \
		 asm volatile("ldg %0, [%0]" : "+r"(_tmp) : : "memory");      \
	   (_tmp >> 56) & 0xF;                                          \
				})

static inline void *mte_alloc(size_t size) {
	    void *ptr = malloc(size);
	        if (!ptr) return NULL;
		    void *tagged = MTE_INSERT_TAG(ptr);
		        MTE_SET_TAG(tagged);
			    return tagged;
}

static inline void *mte_simu(size_t size) {

            void *ptr = malloc(size);
	    if (!ptr) return NULL;
             asm("nop");
	      asm("nop");
	       asm("nop");
	        asm("nop");
		 asm("nop");
		  asm("nop");

	     return ptr;


}	



static inline void mte_free(void *ptr) {
	    free(ptr); 
}

#endif

