#ifndef SECURE_PAC_H
#define SECURE_PAC_H

#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>


static inline  uint64_t sign_pointer(uint64_t ptr, uint64_t modifier) {
	    uint64_t signed_ptr;
	        asm volatile(
				        "pacib %0, %1"
					        : "=r"(signed_ptr)
					  : "r"(modifier), "0"(ptr)
							        : "memory");
		    return signed_ptr;
}


static inline uint64_t au_pointer(uint64_t signed_ptr, uint64_t modifier) {
	    uint64_t authenticated_ptr;
	        asm volatile(
				        "autib %0, %1"
				       : "=r"(authenticated_ptr)
				        : "r"(modifier), "0"(signed_ptr)
						        : "memory");
		    return authenticated_ptr;
}



static void pac_de(uint64_t signed_ptr, uint64_t modifier){

                     uint64_t org_ptr;
		     org_ptr=au_pointer(signed_ptr, modifier);
		     free(org_ptr); 

}

static uint64_t  pac_au(uint64_t signed_ptr, uint64_t modifier){

           uint64_t org_ptr;
	    org_ptr=au_pointer(signed_ptr, modifier);
	    return org_ptr;
}
 static uint64_t new_sign(uint64_t tagged, uint64_t modifier){

            uint64_t signed_ptr;
	    signed_ptr = sign_pointer(tagged, modifier);
	    return signed_ptr; 

 }


static uint64_t au_simu(uint64_t signed_ptr, uint64_t modifier){

           uint64_t org_ptr;
	   asm("nop");
	   asm("nop");
	   asm("nop");
	   asm("nop");
	   return signed_ptr;
          
}

static void free_simu(uint64_t signed_ptr, uint64_t modifier){

                    uint64_t org_ptr;
		    asm("nop");
		    asm("nop");
		    asm("nop");
		    asm("nop");
		    
		    free(signed_ptr);
}


static  uint64_t pac_all(size_t size, uint64_t modifier) {
	    void *raw = malloc(size);
	        if (!raw) {
		       return 0;
	
    				    }
    uint64_t signed_ptr = sign_pointer((uint64_t)raw, modifier);
    	   
    return signed_ptr;
}



static  uint64_t sign_simu(size_t size, uint64_t modifier)
{
                void *raw = malloc(size);
		if (!raw) return 0;
                asm("nop");
		asm("nop");
		asm("nop");
		asm("nop");
		return raw;
               
}



#endif 

