#define LONG64
